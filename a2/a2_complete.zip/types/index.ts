import internal from "stream"

export type ClubMember = {
  name: string,
  netid: string,
  partyParrot: string,
  favoriteIceCream: string,
  favoritefruit: string,
  year: number
}
