import React from "react";

const Footer = () => (
  <footer>
    <hr />
    <span>Created by Joanna Lin (yl797)</span>
  </footer>
);

export default Footer;
